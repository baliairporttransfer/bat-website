import type { FleetVehicle } from "@/types";

export const fleet: FleetVehicle[] = [
  {
    id: "comfort-mpv",
    name: "Toyota Avanza",
    category: "Comfort MPV",
    passengers: 4,
    luggage: 4,
    image: "https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?auto=format&fit=crop&w=1400&q=80",
    features: ["Air-conditioned", "Private ride", "Ideal for couples & small families"]
  },
  {
    id: "premium-mpv",
    name: "Toyota Innova Reborn",
    category: "Premium MPV",
    passengers: 5,
    luggage: 5,
    image: "https://images.unsplash.com/photo-1551830820-330a71b99659?auto=format&fit=crop&w=1400&q=80",
    features: ["Extra comfort", "Spacious cabin", "Perfect for longer journeys"]
  },
  {
    id: "group-van",
    name: "Toyota HiAce",
    category: "Group Van",
    passengers: 12,
    luggage: 10,
    image: "https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=1400&q=80",
    features: ["Group travel", "Large luggage capacity", "Professional driver"]
  }
];
