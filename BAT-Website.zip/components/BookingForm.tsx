"use client";

import { useMemo, useState } from "react";
import { Check, ChevronLeft, ChevronRight, MessageCircle, Minus, Plus } from "lucide-react";
import { destinations } from "@/data/destinations";
import { AIRPORT_PICKUP, CHILD_SEAT_PRICE, HOURLY_CHARTER_RATE } from "@/lib/constants";
import { formatIDR } from "@/lib/utils";
import { createWhatsAppUrl } from "@/lib/whatsapp";
import type { BookingValues, ServiceType } from "@/types";

const initialValues: BookingValues = {
  service: "airport-transfer",
  pickup: AIRPORT_PICKUP,
  destination: "",
  hotel: "",
  date: "",
  time: "",
  flightNumber: "",
  adults: 2,
  children: 0,
  luggage: 2,
  childSeat: false,
  hours: 6,
  firstName: "",
  lastName: "",
  whatsapp: "",
  email: "",
  notes: "",
};

const steps = ["Trip", "Passengers", "Contact", "Summary"];

function NumberField({ label, value, min = 0, max = 20, onChange }: { label: string; value: number; min?: number; max?: number; onChange: (value: number) => void }) {
  return (
    <div className="flex items-center justify-between rounded-2xl border border-slate-200 bg-white px-4 py-3">
      <span className="text-sm font-semibold text-navy-900">{label}</span>
      <div className="flex items-center gap-3">
        <button type="button" onClick={() => onChange(Math.max(min, value - 1))} className="grid h-9 w-9 place-items-center rounded-full border border-slate-200 text-navy-900 hover:bg-slate-50" aria-label={`Decrease ${label}`}><Minus size={16} /></button>
        <span className="w-6 text-center font-bold text-navy-900">{value}</span>
        <button type="button" onClick={() => onChange(Math.min(max, value + 1))} className="grid h-9 w-9 place-items-center rounded-full border border-slate-200 text-navy-900 hover:bg-slate-50" aria-label={`Increase ${label}`}><Plus size={16} /></button>
      </div>
    </div>
  );
}

export function BookingForm() {
  const [step, setStep] = useState(0);
  const [values, setValues] = useState<BookingValues>(initialValues);
  const [error, setError] = useState("");
  const selectedDestination = destinations.find((item) => item.id === values.destination);
  const total = useMemo(() => {
    const base = values.service === "airport-transfer" ? selectedDestination?.price ?? 0 : values.hours * HOURLY_CHARTER_RATE;
    return base + (values.childSeat ? CHILD_SEAT_PRICE : 0);
  }, [selectedDestination, values.childSeat, values.hours, values.service]);

  const update = <K extends keyof BookingValues>(key: K, value: BookingValues[K]) => setValues((current) => ({ ...current, [key]: value }));

  function validateCurrentStep() {
    if (step === 0 && (!values.pickup || !values.destination || !values.date || !values.time)) return "Please complete pickup, destination, date, and time.";
    if (step === 2 && (!values.firstName || !values.lastName || !values.whatsapp || !values.email)) return "Please complete your name, WhatsApp number, and email.";
    return "";
  }

  function nextStep() {
    const message = validateCurrentStep();
    if (message) return setError(message);
    setError("");
    setStep((current) => Math.min(steps.length - 1, current + 1));
  }

  return (
    <section id="booking" className="relative z-20 -mt-24 pb-20 sm:-mt-28">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="overflow-hidden rounded-[2rem] border border-white/40 bg-white shadow-luxury">
          <div className="bg-navy-900 px-5 py-5 sm:px-8">
            <div className="flex items-center justify-between gap-3 overflow-x-auto">
              {steps.map((label, index) => (
                <div key={label} className="flex min-w-fit items-center gap-2">
                  <span className={`grid h-8 w-8 place-items-center rounded-full text-xs font-bold ${index <= step ? "bg-gold-500 text-navy-900" : "bg-white/10 text-white/60"}`}>{index < step ? <Check size={15} /> : index + 1}</span>
                  <span className={`text-xs font-semibold sm:text-sm ${index <= step ? "text-white" : "text-white/50"}`}>{label}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="grid lg:grid-cols-[1fr_320px]">
            <div className="p-5 sm:p-8 lg:p-10">
              {step === 0 ? (
                <div>
                  <h2 className="text-2xl font-semibold text-navy-900">Plan your journey</h2>
                  <p className="mt-2 text-sm text-slate-600">Choose a private airport transfer or a flexible hourly charter.</p>
                  <div className="mt-6 grid grid-cols-2 gap-3">
                    {(["airport-transfer", "hourly-charter"] as ServiceType[]).map((service) => (
                      <button key={service} type="button" onClick={() => update("service", service)} className={`rounded-2xl border p-4 text-left transition ${values.service === service ? "border-gold-500 bg-gold-50 ring-2 ring-gold-500/20" : "border-slate-200 hover:border-slate-300"}`}>
                        <span className="block text-sm font-bold text-navy-900">{service === "airport-transfer" ? "Airport Transfer" : "Hourly Charter"}</span>
                        <span className="mt-1 block text-xs text-slate-500">{service === "airport-transfer" ? "Airport to hotel or villa" : "Private car with driver"}</span>
                      </button>
                    ))}
                  </div>
                  <div className="mt-6 grid gap-4 sm:grid-cols-2">
                    <label className="sm:col-span-2"><span className="field-label">Pickup</span><input className="field-input" value={values.pickup} onChange={(event) => update("pickup", event.target.value)} /></label>
                    <label className="sm:col-span-2"><span className="field-label">Destination</span><select className="field-input" value={values.destination} onChange={(event) => update("destination", event.target.value)}><option value="">Select destination</option>{destinations.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
                    <label className="sm:col-span-2"><span className="field-label">Hotel / Villa</span><input className="field-input" value={values.hotel} onChange={(event) => update("hotel", event.target.value)} placeholder="Property name or address" /></label>
                    <label><span className="field-label">Date</span><input type="date" className="field-input" value={values.date} onChange={(event) => update("date", event.target.value)} /></label>
                    <label><span className="field-label">Arrival / Pickup Time</span><input type="time" className="field-input" value={values.time} onChange={(event) => update("time", event.target.value)} /></label>
                    <label className="sm:col-span-2"><span className="field-label">Flight Number</span><input className="field-input" value={values.flightNumber} onChange={(event) => update("flightNumber", event.target.value)} placeholder="e.g. SQ946" /></label>
                    {values.service === "hourly-charter" ? <label className="sm:col-span-2"><span className="field-label">Charter duration</span><select className="field-input" value={values.hours} onChange={(event) => update("hours", Number(event.target.value))}>{[6,8,10,12].map((hours) => <option key={hours} value={hours}>{hours} hours</option>)}</select></label> : null}
                  </div>
                </div>
              ) : null}

              {step === 1 ? (
                <div>
                  <h2 className="text-2xl font-semibold text-navy-900">Passengers & luggage</h2>
                  <p className="mt-2 text-sm text-slate-600">Help us prepare the right vehicle for your group.</p>
                  <div className="mt-6 grid gap-4 sm:grid-cols-2">
                    <NumberField label="Adults" value={values.adults} min={1} onChange={(value) => update("adults", value)} />
                    <NumberField label="Children" value={values.children} onChange={(value) => update("children", value)} />
                    <NumberField label="Luggage" value={values.luggage} onChange={(value) => update("luggage", value)} />
                    <label className="flex cursor-pointer items-center justify-between rounded-2xl border border-slate-200 bg-white px-4 py-3"><span><span className="block text-sm font-semibold text-navy-900">Child seat</span><span className="text-xs text-slate-500">+ {formatIDR(CHILD_SEAT_PRICE)}</span></span><input type="checkbox" checked={values.childSeat} onChange={(event) => update("childSeat", event.target.checked)} className="h-5 w-5 accent-gold-500" /></label>
                  </div>
                </div>
              ) : null}

              {step === 2 ? (
                <div>
                  <h2 className="text-2xl font-semibold text-navy-900">Your contact details</h2>
                  <p className="mt-2 text-sm text-slate-600">We use these details only to confirm and manage your transfer.</p>
                  <div className="mt-6 grid gap-4 sm:grid-cols-2">
                    <label><span className="field-label">First name</span><input className="field-input" value={values.firstName} onChange={(event) => update("firstName", event.target.value)} /></label>
                    <label><span className="field-label">Last name</span><input className="field-input" value={values.lastName} onChange={(event) => update("lastName", event.target.value)} /></label>
                    <label><span className="field-label">WhatsApp</span><input type="tel" className="field-input" value={values.whatsapp} onChange={(event) => update("whatsapp", event.target.value)} placeholder="Include country code" /></label>
                    <label><span className="field-label">Email</span><input type="email" className="field-input" value={values.email} onChange={(event) => update("email", event.target.value)} /></label>
                    <label className="sm:col-span-2"><span className="field-label">Notes</span><textarea className="field-input min-h-28 resize-y" value={values.notes} onChange={(event) => update("notes", event.target.value)} placeholder="Special requests, extra stop, accessibility needs..." /></label>
                  </div>
                </div>
              ) : null}

              {step === 3 ? (
                <div>
                  <h2 className="text-2xl font-semibold text-navy-900">Review your booking</h2>
                  <p className="mt-2 text-sm text-slate-600">Check the details below, then send your request through WhatsApp.</p>
                  <dl className="mt-6 divide-y divide-slate-100 rounded-2xl border border-slate-200 px-5">
                    {[['Service', values.service === 'airport-transfer' ? 'Airport Transfer' : 'Hourly Charter'], ['Pickup', values.pickup], ['Destination', selectedDestination?.name ?? '-'], ['Hotel / Villa', values.hotel || '-'], ['Date & time', `${values.date} at ${values.time}`], ['Flight', values.flightNumber || '-'], ['Passengers', `${values.adults} adult(s), ${values.children} child(ren)`], ['Luggage', String(values.luggage)], ['Child seat', values.childSeat ? 'Yes' : 'No'], ['Passenger', `${values.firstName} ${values.lastName}`], ['WhatsApp', values.whatsapp], ['Email', values.email]].map(([term, description]) => <div key={term} className="grid grid-cols-[120px_1fr] gap-4 py-3 text-sm"><dt className="font-semibold text-slate-500">{term}</dt><dd className="font-medium text-navy-900">{description}</dd></div>)}
                  </dl>
                  <a href={createWhatsAppUrl(values, total)} target="_blank" rel="noreferrer" className="mt-6 inline-flex h-14 w-full items-center justify-center gap-2 rounded-full bg-[#25D366] px-6 font-bold text-white transition hover:brightness-95"><MessageCircle size={20} /> Book via WhatsApp</a>
                </div>
              ) : null}

              {error ? <p className="mt-5 rounded-xl bg-red-50 px-4 py-3 text-sm font-medium text-red-700">{error}</p> : null}
              <div className="mt-8 flex items-center justify-between gap-3">
                <button type="button" onClick={() => { setError(""); setStep((current) => Math.max(0, current - 1)); }} disabled={step === 0} className="inline-flex h-12 items-center gap-2 rounded-full border border-slate-200 px-5 text-sm font-bold text-navy-900 disabled:cursor-not-allowed disabled:opacity-40"><ChevronLeft size={17} /> Back</button>
                {step < steps.length - 1 ? <button type="button" onClick={nextStep} className="inline-flex h-12 items-center gap-2 rounded-full bg-navy-900 px-6 text-sm font-bold text-white transition hover:bg-navy-800">Continue <ChevronRight size={17} /></button> : null}
              </div>
            </div>

            <aside className="bg-slate-50 p-5 sm:p-8 lg:p-7">
              <p className="text-xs font-bold uppercase tracking-[0.22em] text-gold-600">Price summary</p>
              <div className="mt-5 rounded-2xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
                <p className="text-sm text-slate-500">Estimated total</p>
                <p className="mt-2 text-3xl font-bold text-navy-900">{total ? formatIDR(total) : "Select destination"}</p>
                {selectedDestination ? <p className="mt-2 text-sm text-slate-500">{selectedDestination.name} · {selectedDestination.travelTime}</p> : null}
                {values.childSeat ? <div className="mt-4 flex justify-between border-t border-slate-100 pt-4 text-sm"><span className="text-slate-500">Child seat</span><span className="font-semibold text-navy-900">{formatIDR(CHILD_SEAT_PRICE)}</span></div> : null}
              </div>
              <ul className="mt-6 space-y-3 text-sm text-slate-600">{["Private, air-conditioned vehicle", "Professional English-speaking driver", "Airport meet & greet", "Instant WhatsApp confirmation"].map((item) => <li key={item} className="flex gap-2"><Check size={17} className="mt-0.5 shrink-0 text-gold-600" />{item}</li>)}</ul>
              <p className="mt-6 text-xs leading-5 text-slate-500">Final vehicle and any route-specific surcharge will be confirmed before booking. No payment is taken on this website.</p>
            </aside>
          </div>
        </div>
      </div>
    </section>
  );
}
