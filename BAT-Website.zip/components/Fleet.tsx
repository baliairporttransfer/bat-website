import Image from "next/image";
import { Briefcase, Check, Users } from "lucide-react";
import { Container } from "@/components/Container";
import { SectionHeading } from "@/components/SectionHeading";
import { fleet } from "@/data/fleet";

export function Fleet() {
  return <section id="fleet" className="bg-white py-20 sm:py-28"><Container><SectionHeading eyebrow="Our fleet" title="Comfort for every kind of journey" description="Clean, air-conditioned vehicles selected according to your group size, luggage, and route." /><div className="mt-12 grid gap-6 lg:grid-cols-3">{fleet.map((vehicle) => <article key={vehicle.id} className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm"><div className="relative h-56"><Image src={vehicle.image} alt={vehicle.name} fill sizes="(max-width: 1024px) 100vw, 33vw" className="object-cover" /></div><div className="p-6"><p className="text-xs font-bold uppercase tracking-widest text-gold-600">{vehicle.category}</p><h3 className="mt-2 text-2xl font-bold text-navy-900">{vehicle.name}</h3><div className="mt-4 flex gap-5 text-sm text-slate-600"><span className="flex items-center gap-2"><Users size={17} />Up to {vehicle.passengers}</span><span className="flex items-center gap-2"><Briefcase size={17} />{vehicle.luggage} bags</span></div><ul className="mt-5 space-y-2">{vehicle.features.map((feature) => <li key={feature} className="flex items-center gap-2 text-sm text-slate-600"><Check size={16} className="text-gold-600" />{feature}</li>)}</ul></div></article>)}</div></Container></section>;
}
