import Image from "next/image";
import Link from "next/link";
import { ArrowRight, BadgeCheck, Clock3, ShieldCheck, Star } from "lucide-react";
import { Container } from "@/components/Container";
import { SITE_CONFIG } from "@/lib/constants";

export function Hero() {
  return (
    <section id="top" className="relative min-h-[820px] overflow-hidden bg-navy-900 pt-20 sm:min-h-[860px]">
      <Image src={SITE_CONFIG.heroImage} alt="Ulun Danu Beratan temple in Bali" fill priority sizes="100vw" className="object-cover" />
      <div className="absolute inset-0 bg-hero-overlay" />
      <div className="absolute inset-0 bg-gradient-to-t from-navy-900 via-transparent to-transparent" />
      <Container className="relative flex min-h-[740px] items-center py-20 sm:min-h-[780px]">
        <div className="max-w-3xl">
          <div className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-2 text-sm text-white backdrop-blur">
            <span className="flex text-gold-400">{Array.from({ length: 5 }).map((_, index) => <Star key={index} size={14} fill="currentColor" />)}</span>
            <span className="font-semibold">5-star rated Bali transfers</span>
          </div>
          <h1 className="mt-7 text-4xl font-semibold leading-[1.08] tracking-tight text-white sm:text-6xl lg:text-7xl">Private Airport Transfer <span className="text-gold-400">Across Bali</span></h1>
          <p className="mt-6 max-w-2xl text-lg leading-8 text-white/80 sm:text-xl">Reliable airport transfers with fixed prices, professional English-speaking drivers, and instant WhatsApp confirmation.</p>
          <div className="mt-9 flex flex-col gap-3 sm:flex-row">
            <Link href="#booking" className="inline-flex h-14 items-center justify-center gap-2 rounded-full bg-gold-500 px-7 font-bold text-navy-900 transition hover:bg-gold-400">Book your transfer <ArrowRight size={18} /></Link>
            <Link href="#prices" className="inline-flex h-14 items-center justify-center rounded-full border border-white/30 bg-white/10 px-7 font-semibold text-white backdrop-blur transition hover:bg-white/20">View fixed prices</Link>
          </div>
          <div className="mt-10 grid max-w-2xl grid-cols-1 gap-3 sm:grid-cols-3">
            {[{ icon: ShieldCheck, text: "Fixed, clear pricing" }, { icon: Clock3, text: "Flight monitoring" }, { icon: BadgeCheck, text: "Trusted local drivers" }].map(({ icon: Icon, text }) => (
              <div key={text} className="flex items-center gap-3 rounded-2xl border border-white/10 bg-navy-900/45 px-4 py-3 text-sm font-medium text-white backdrop-blur"><Icon className="text-gold-400" size={20} />{text}</div>
            ))}
          </div>
        </div>
      </Container>
    </section>
  );
}
